--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15rc2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bilet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bilet (
    "biletID" integer NOT NULL,
    "otobusID" integer,
    "seferID" integer,
    "musteriID" integer,
    "koltukNO" integer,
    "biletTarihi" text
);


ALTER TABLE public.bilet OWNER TO postgres;

--
-- Name: marka; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marka (
    "markaID" integer NOT NULL,
    "markaAdi" character varying
);


ALTER TABLE public.marka OWNER TO postgres;

--
-- Name: memurlar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memurlar (
    "memurID" integer NOT NULL,
    "sirketID" integer,
    ad character varying,
    soyad character varying,
    dogumtarihi character varying
);


ALTER TABLE public.memurlar OWNER TO postgres;

--
-- Name: musteri_musterihizmetleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musteri_musterihizmetleri (
    "hizmetID" integer NOT NULL,
    "musteriID" integer NOT NULL
);


ALTER TABLE public.musteri_musterihizmetleri OWNER TO postgres;

--
-- Name: musterihizmetleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musterihizmetleri (
    "hizmetID" integer NOT NULL,
    "iletisimNo" character varying
);


ALTER TABLE public.musterihizmetleri OWNER TO postgres;

--
-- Name: musteriler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musteriler (
    "musteriID" integer NOT NULL,
    adi character varying,
    soyaadi character varying,
    "kimlikNo" character varying(11) NOT NULL
);


ALTER TABLE public.musteriler OWNER TO postgres;

--
-- Name: otobus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otobus (
    "otobusID" integer NOT NULL,
    "markaID" integer,
    "sırketID" integer
);


ALTER TABLE public.otobus OWNER TO postgres;

--
-- Name: otobus_masraflar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otobus_masraflar (
    "otobus_masraflarID" integer NOT NULL,
    "otobusID" integer,
    tutar money
);


ALTER TABLE public.otobus_masraflar OWNER TO postgres;

--
-- Name: personal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal (
    "memurID" integer NOT NULL,
    "personalTipi" character varying
);


ALTER TABLE public.personal OWNER TO postgres;

--
-- Name: seferler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seferler (
    "seferlerID" integer NOT NULL,
    tarih text,
    saat text
);


ALTER TABLE public.seferler OWNER TO postgres;

--
-- Name: sehir; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sehir (
    "sehirID" integer NOT NULL,
    "sehirAdi" character varying,
    "sehirKodu" character varying
);


ALTER TABLE public.sehir OWNER TO postgres;

--
-- Name: sehit_otobus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sehit_otobus (
    "sehirID" integer NOT NULL,
    "otobusID" integer NOT NULL
);


ALTER TABLE public.sehit_otobus OWNER TO postgres;

--
-- Name: sirket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sirket (
    "sirketID" integer NOT NULL,
    "sirketAdi" character varying
);


ALTER TABLE public.sirket OWNER TO postgres;

--
-- Name: sirketIletisim; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."sirketIletisim" (
    "sirketIletisimID" integer NOT NULL,
    "sirketNo" integer,
    mail character varying,
    telefon character varying
);


ALTER TABLE public."sirketIletisim" OWNER TO postgres;

--
-- Name: sofor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sofor (
    "memurID" integer NOT NULL,
    ad character varying
);


ALTER TABLE public.sofor OWNER TO postgres;

--
-- Name: musteri_musterihizmetleri musteri_musterihizmetleri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri_musterihizmetleri
    ADD CONSTRAINT musteri_musterihizmetleri_pkey PRIMARY KEY ("hizmetID", "musteriID");


--
-- Name: musterihizmetleri musterihizmetleri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musterihizmetleri
    ADD CONSTRAINT musterihizmetleri_pkey PRIMARY KEY ("hizmetID");


--
-- Name: seferler seferler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seferler
    ADD CONSTRAINT seferler_pkey PRIMARY KEY ("seferlerID");


--
-- Name: sehit_otobus sehit_otobus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehit_otobus
    ADD CONSTRAINT sehit_otobus_pkey PRIMARY KEY ("otobusID", "sehirID");


--
-- Name: sofor sofor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sofor
    ADD CONSTRAINT sofor_pkey PRIMARY KEY ("memurID");


--
-- Name: bilet unique_bilet_biletID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT "unique_bilet_biletID" PRIMARY KEY ("biletID");


--
-- Name: bilet unique_bilet_musteriID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT "unique_bilet_musteriID" UNIQUE ("musteriID");


--
-- Name: bilet unique_bilet_otobusID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT "unique_bilet_otobusID" UNIQUE ("otobusID");


--
-- Name: bilet unique_bilet_seferID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT "unique_bilet_seferID" UNIQUE ("seferID");


--
-- Name: marka unique_marka_markaID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marka
    ADD CONSTRAINT "unique_marka_markaID" PRIMARY KEY ("markaID");


--
-- Name: memurlar unique_memurler_memurID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memurlar
    ADD CONSTRAINT "unique_memurler_memurID" PRIMARY KEY ("memurID");


--
-- Name: memurlar unique_memurler_sirketID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memurlar
    ADD CONSTRAINT "unique_memurler_sirketID" UNIQUE ("sirketID");


--
-- Name: musteri_musterihizmetleri unique_musteri_musterihizmetleri_hizmetID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri_musterihizmetleri
    ADD CONSTRAINT "unique_musteri_musterihizmetleri_hizmetID" UNIQUE ("hizmetID");


--
-- Name: musteri_musterihizmetleri unique_musteri_musterihizmetleri_musteriID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri_musterihizmetleri
    ADD CONSTRAINT "unique_musteri_musterihizmetleri_musteriID" UNIQUE ("musteriID");


--
-- Name: musterihizmetleri unique_musterihizmetleri_hizmetID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musterihizmetleri
    ADD CONSTRAINT "unique_musterihizmetleri_hizmetID" UNIQUE ("hizmetID");


--
-- Name: musteriler unique_musteriler_musteriID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteriler
    ADD CONSTRAINT "unique_musteriler_musteriID" PRIMARY KEY ("musteriID");


--
-- Name: otobus unique_otobus_markaID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT "unique_otobus_markaID" UNIQUE ("markaID");


--
-- Name: otobus_masraflar unique_otobus_masraflar_otobusID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus_masraflar
    ADD CONSTRAINT "unique_otobus_masraflar_otobusID" UNIQUE ("otobusID");


--
-- Name: otobus_masraflar unique_otobus_masraflar_otobus_masraflarID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus_masraflar
    ADD CONSTRAINT "unique_otobus_masraflar_otobus_masraflarID" PRIMARY KEY ("otobus_masraflarID");


--
-- Name: otobus unique_otobus_otobusID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT "unique_otobus_otobusID" PRIMARY KEY ("otobusID");


--
-- Name: otobus unique_otobus_sırketID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT "unique_otobus_sırketID" UNIQUE ("sırketID");


--
-- Name: personal unique_personal_memurID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal
    ADD CONSTRAINT "unique_personal_memurID" PRIMARY KEY ("memurID");


--
-- Name: seferler unique_seferler_seferlerID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seferler
    ADD CONSTRAINT "unique_seferler_seferlerID" UNIQUE ("seferlerID");


--
-- Name: sehir unique_sehir_sehirID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehir
    ADD CONSTRAINT "unique_sehir_sehirID" PRIMARY KEY ("sehirID");


--
-- Name: sehit_otobus unique_sehit_otobus_otobusID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehit_otobus
    ADD CONSTRAINT "unique_sehit_otobus_otobusID" UNIQUE ("otobusID");


--
-- Name: sehit_otobus unique_sehit_otobus_sehirID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehit_otobus
    ADD CONSTRAINT "unique_sehit_otobus_sehirID" UNIQUE ("sehirID");


--
-- Name: sirketIletisim unique_sirketIletisim_sirketIletisimID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sirketIletisim"
    ADD CONSTRAINT "unique_sirketIletisim_sirketIletisimID" PRIMARY KEY ("sirketIletisimID");


--
-- Name: sirketIletisim unique_sirketIletisim_sirketNo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sirketIletisim"
    ADD CONSTRAINT "unique_sirketIletisim_sirketNo" UNIQUE ("sirketNo");


--
-- Name: sirket unique_sirket_sirketID; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sirket
    ADD CONSTRAINT "unique_sirket_sirketID" PRIMARY KEY ("sirketID");


--
-- Name: index_hizmetID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "index_hizmetID" ON public.musteri_musterihizmetleri USING btree ("hizmetID");


--
-- Name: index_otobusID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "index_otobusID" ON public.sehit_otobus USING btree ("otobusID");


--
-- Name: musteriler bilet_musteri; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteriler
    ADD CONSTRAINT bilet_musteri FOREIGN KEY ("musteriID") REFERENCES public.bilet("musteriID") MATCH FULL;


--
-- Name: otobus bilet_otobus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT bilet_otobus FOREIGN KEY ("otobusID") REFERENCES public.bilet("otobusID") MATCH FULL;


--
-- Name: otobus marka_otobus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT marka_otobus FOREIGN KEY ("markaID") REFERENCES public.marka("markaID") MATCH FULL;


--
-- Name: personal memurler_personal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal
    ADD CONSTRAINT memurler_personal FOREIGN KEY ("memurID") REFERENCES public.memurlar("memurID") MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sofor memurler_sofor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sofor
    ADD CONSTRAINT memurler_sofor FOREIGN KEY ("memurID") REFERENCES public.memurlar("memurID") MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: musteri_musterihizmetleri musteriMusteriHizmetleri_MusteriHiz; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri_musterihizmetleri
    ADD CONSTRAINT "musteriMusteriHizmetleri_MusteriHiz" FOREIGN KEY ("hizmetID") REFERENCES public.musterihizmetleri("hizmetID") MATCH FULL;


--
-- Name: musteri_musterihizmetleri musteri_musteriHIZ; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri_musterihizmetleri
    ADD CONSTRAINT "musteri_musteriHIZ" FOREIGN KEY ("musteriID") REFERENCES public.musteriler("musteriID") MATCH FULL;


--
-- Name: otobus otobus_masraflari_otobus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otobus
    ADD CONSTRAINT otobus_masraflari_otobus FOREIGN KEY ("otobusID") REFERENCES public.otobus_masraflar("otobusID") MATCH FULL;


--
-- Name: sehit_otobus otobus_sehir_otobus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehit_otobus
    ADD CONSTRAINT otobus_sehir_otobus FOREIGN KEY ("otobusID") REFERENCES public.otobus("otobusID") MATCH FULL;


--
-- Name: sirket otobus_sirket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sirket
    ADD CONSTRAINT otobus_sirket FOREIGN KEY ("sirketID") REFERENCES public.otobus("sırketID") MATCH FULL;


--
-- Name: bilet sefer_bilet; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT sefer_bilet FOREIGN KEY ("seferID") REFERENCES public.seferler("seferlerID") MATCH FULL;


--
-- Name: sehit_otobus sehir_otobus_sehir; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehit_otobus
    ADD CONSTRAINT sehir_otobus_sehir FOREIGN KEY ("sehirID") REFERENCES public.sehir("sehirID") MATCH FULL;


--
-- Name: memurlar sirket_memurler; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memurlar
    ADD CONSTRAINT sirket_memurler FOREIGN KEY ("sirketID") REFERENCES public.sirket("sirketID") MATCH FULL;


--
-- Name: sirketIletisim sirket_sirketiletisim; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sirketIletisim"
    ADD CONSTRAINT sirket_sirketiletisim FOREIGN KEY ("sirketNo") REFERENCES public.sirket("sirketID") MATCH FULL;


--
-- PostgreSQL database dump complete
--

