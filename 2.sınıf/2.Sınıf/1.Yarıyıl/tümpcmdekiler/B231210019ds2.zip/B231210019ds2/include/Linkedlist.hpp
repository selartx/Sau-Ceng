/**
* @file B231210019 Veri Yapıları Ödev 1
* @description Dna  sınıfının methodlarının yazılması* 
*@course 1/A
* @assignment 1
* @date 26/11/2024
* @author Selva Artunç selva.artunc@ogr.sakarya.edu.tr
*/
#ifndef LINKEDLIST_HPP
#define LINKEDLIST_HPP
#include "Bst.hpp"
#include <iostream>

using namespace std;

class LinkedList
{ 
	public:
	struct ListeDugum{
		BST Agac;
		ListeDugum *sonraki;
		ListeDugum();
		~ListeDugum();
	};
	ListeDugum *head;
	ListeDugum *current;
	LinkedList();
	~LinkedList();
	void Agacekle(BST);
	void AgacSil();
	void ileri();
	void tablociz(int baslangicIndex, int maxGosterim, int secilenIndex);
	void SeciliAgacCiz(int secilenIndex);
	void SeciliAgaciAynaYap(int secilenIndex);
	int DugumSayisi();
};

#endif