/**
* @file B231210019 Veri Yapıları Ödev 1
* @description Dna  sınıfının methodlarının yazılması* 
*@course 1/A
* @assignment 1
* @date 26/11/2024
* @author Selva Artunç selva.artunc@ogr.sakarya.edu.tr
*/
#ifndef BST_HPP
#define BST_HPP
#include <iostream>
using namespace std;

class BST
{ 	
	public:
	struct AgacDugum{
		char veri;
		int level;
		AgacDugum *sol;
		AgacDugum *sag;
		AgacDugum();
		~AgacDugum();
	};
	AgacDugum *kok;
	BST();
	~BST();
	void agacolustur(const string &veri);
	int agacdegeri(AgacDugum* dugum, bool isLeftChild) ;
	void agaccizdir();
	void agaciDoldur(AgacDugum* node, char ekran[][150], int satir, int sol, int sag);
	int agacDerinligi(AgacDugum* dugum);
	void aynalama(AgacDugum* dugum);
	};
	
#endif