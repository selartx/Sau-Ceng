/**
* @file B231210019 Veri Yapıları Ödev 1
* @description Dna  sınıfının methodlarının yazılması* 
*@course 1/A
* @assignment 1
* @date 26/11/2024
* @author Selva Artunç selva.artunc@ogr.sakarya.edu.tr
*/
#include "Bst.hpp"
#include <iostream>
#include <fstream>
using namespace std;

BST::AgacDugum::AgacDugum(){
	sol=NULL;
	sag=NULL;
    level=0;
}
BST::AgacDugum::~AgacDugum(){
	sol=NULL;
	sag=NULL;
    level=0;
}
BST::BST()
{ 	
	kok = NULL;
}
BST::~BST()
{ 	
	kok = NULL;
}

void BST::agacolustur(const string &veri) {
    for (char c : veri) {
        AgacDugum *newNode = new AgacDugum();
        newNode->veri = c;

        if (kok == nullptr) {
            kok = newNode;
            newNode->level = 0; 
        } else {
            AgacDugum *current = kok;
            AgacDugum *parent = nullptr;
            int counter_level = 0; 
            while (current != nullptr) {
                parent = current;
                if (c < current->veri) { 
                    current = current->sol;
                } else {
                    current = current->sag;
                }
                counter_level++;
            }
            newNode->level = counter_level; 
            if (c < parent->veri) {  
                parent->sol = newNode;
            } else {
                parent->sag = newNode;
            }
        }
    }
}

void BST::agaccizdir() {
    if (!kok) {
        cout << "Ağacı boş." << endl;
        return;
    }

    
    int derinlik = agacDerinligi(kok);

    
    const int genislik = 150; 
    const int yukseklik = derinlik * 3; 
    char ekran[yukseklik][genislik];

  
    for (int i = 0; i < yukseklik; i++) {
        for (int j = 0; j < genislik; j++) {
            ekran[i][j] = ' ';
        }
    }

   
    agaciDoldur(kok, ekran, 0, 0, genislik - 1);

    
    for (int i = 0; i < yukseklik; i++) {
        for (int j = 0; j < genislik; j++) {
            cout << ekran[i][j];
        }
        cout << endl;
    }
    cout << endl;
}

void BST::agaciDoldur(AgacDugum* node, char ekran[][150], int satir, int sol, int sag) {
    if (!node) return;

  
    int orta = (sol + sag) / 2;
    
    ekran[satir][orta] = node->veri; 

    if (node->sol) {
        int altOrta = (sol + orta) / 2;
     
        for (int i = orta - 1; i >= altOrta; i--) {
            ekran[satir + 1][i] = '.';
        }
        ekran[satir + 2][altOrta] = '.';
        agaciDoldur(node->sol, ekran, satir + 3, sol, orta - 1);
    }
    if (node->sag) {
        int altOrta = (orta + sag) / 2;
       
        for (int i = orta + 1; i <= altOrta; i++) {
            ekran[satir + 1][i] = '.';
        }
        ekran[satir + 2][altOrta] = '.'; 
        agaciDoldur(node->sag, ekran, satir + 3, orta + 1, sag);
    }
}




int BST::agacdegeri(AgacDugum* dugum, bool isLeftChild = false) {
    if (!dugum) return 0;

    
    int solDeger = agacdegeri(dugum->sol, true);  
    int sagDeger = agacdegeri(dugum->sag, false); 

    int currentValue = isLeftChild ? (dugum->veri * 2) : dugum->veri;

    return solDeger + sagDeger + currentValue;
}
void BST::aynalama(AgacDugum* dugum) {
    if (!dugum) return; 
    swap(dugum->sol, dugum->sag); 
    aynalama(dugum->sol);         
    aynalama(dugum->sag);       
}



int BST::agacDerinligi(AgacDugum* dugum) {
    if (dugum == nullptr) {
        return 0; 
    }
   
    int solDerinlik = agacDerinligi(dugum->sol);
    int sagDerinlik = agacDerinligi(dugum->sag);

    return max(solDerinlik, sagDerinlik) + 1;
}
