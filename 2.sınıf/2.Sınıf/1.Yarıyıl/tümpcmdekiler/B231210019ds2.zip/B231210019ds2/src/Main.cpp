/**
* @file B231210019 Veri Yapıları Ödev 1
* @description Dna  sınıfının methodlarının yazılması* 
*@course 1/A
* @assignment 1
* @date 26/11/2024
* @author Selva Artunç selva.artunc@ogr.sakarya.edu.tr
*/
#include "Linkedlist.hpp"
#include "Bst.hpp"
#include <iostream>
#include <fstream>

using namespace std;

int main() {
    LinkedList linkedList;
    char choice;
    int secilenIndex = 0; 
    const int maxGosterim = 10; 
    int baslangicIndex = 0; 

    ifstream file("agaclar.txt"); 
    if (!file.is_open()) {
        cerr << "Dosya açılamadı!" << endl;
        return 1;
    }

  
    string line;
    cout << "Dosyadan ağaçlar okunuyor..." << endl;
    while (getline(file, line)) {
        if (!line.empty()) {
            BST yeniAgac;
            yeniAgac.agacolustur(line);    
            linkedList.Agacekle(yeniAgac); 
        }
    }

    file.close();

    bool devamEt = true;
    while (devamEt) {
        system("cls"); 
        linkedList.tablociz(baslangicIndex, maxGosterim, secilenIndex); 
        linkedList.SeciliAgacCiz(secilenIndex); 






        cout << "\nSeçim:\n";
        cin >> choice;

        switch (choice) {
            case 'a': 
                if (secilenIndex > 0) {
                    secilenIndex--; 
                    if (secilenIndex < baslangicIndex) {
                        baslangicIndex -= maxGosterim; 
                        if (baslangicIndex < 0) baslangicIndex = 0; 
                    }
                }
                break;

            case 'd':
                if (secilenIndex + 1 < linkedList.DugumSayisi()) {
                    secilenIndex++;
                    if (secilenIndex >= baslangicIndex + maxGosterim) {
                        baslangicIndex += maxGosterim; 
                        if (baslangicIndex >= linkedList.DugumSayisi()) {
                            baslangicIndex = linkedList.DugumSayisi() - maxGosterim;
                    }
                }
                break;
                }
            case 'q': 
                devamEt = false;
                break;

            case 'w':
                linkedList.SeciliAgaciAynaYap(secilenIndex);
                break;

            default:
                cout << "Geçersiz seçim!" << endl;
                break;
        }
    }
     
    return 0;
}
